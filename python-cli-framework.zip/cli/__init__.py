"""
Python CLI Framework Starter Kit
Built by Jackson Studio
"""

__version__ = "1.0.0"
__author__ = "Jackson Studio"
__license__ = "MIT"
